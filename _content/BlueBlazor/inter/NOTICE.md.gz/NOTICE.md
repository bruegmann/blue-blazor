﻿Downloaded from the GitHub Releases [rsms/inter](https://github.com/rsms/inter/releases).
We only ship the variable font files and the static font files for the Regular weight and Italic.