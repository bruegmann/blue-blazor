export function hidePopover(element) {
    if (element) element.hidePopover()
}
