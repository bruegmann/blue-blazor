export function hidePopover(element) {
    if (element) element.hidePopover()
}

export function showPopover(element) {
    if (element) element.showPopover()
}