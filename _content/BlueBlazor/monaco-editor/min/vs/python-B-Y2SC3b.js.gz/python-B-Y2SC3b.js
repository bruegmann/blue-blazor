<Project Sdk="Microsoft.VisualStudio.JavaScript.Sdk/1.0.3134461">
	<PropertyGroup>
		<DebugAssetsDirectory>dist\</DebugAssetsDirectory>
		<StaticWebAssetSourceId>BlueBlazor</StaticWebAssetSourceId>
		<BuildCommand>npm run build</BuildCommand>
		<CleanCommand>npm run clean</CleanCommand>
	</PropertyGroup>

    <Target Name="EnsureNodeModules" BeforeTargets="Build">
        <Exec Command="npm install" Condition="!Exists('$(MSBuildThisFileDirectory)\node_modules')" />
    </Target>
</Project>